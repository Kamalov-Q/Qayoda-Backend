import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, In, Repository } from 'typeorm';
import { ClickPayment } from './entities/click-payment.entity';
import { Wallet } from './entities/wallet.entity';
import { Tariff } from './entities/tariff.entity';
import { BonusTier } from './entities/bonus-tier.entity';
import { User } from '../users/entities/user.entity';
import { WalletService } from './wallet.service';
import {
  AdminAdjustDto,
  AdminPaymentsQueryDto,
  CreateBonusTierDto,
  PageDto,
  UpdateBonusTierDto,
  UpdateTariffDto,
} from './dto/billing.dto';

const DAY_MS = 24 * 60 * 60 * 1000;

@Injectable()
export class BillingAdminService {
  constructor(
    @InjectRepository(ClickPayment)
    private readonly payments: Repository<ClickPayment>,
    @InjectRepository(Wallet) private readonly wallets: Repository<Wallet>,
    @InjectRepository(Tariff) private readonly tariffs: Repository<Tariff>,
    @InjectRepository(BonusTier) private readonly tiers: Repository<BonusTier>,
    @InjectRepository(User) private readonly users: Repository<User>,
    private readonly wallet: WalletService,
    private readonly dataSource: DataSource,
  ) {}

  // ------------------------------------------------------------ tariffs

  listTariffs() {
    return this.tariffs.find({ order: { key: 'ASC' } });
  }

  async updateTariff(key: string, dto: UpdateTariffDto) {
    const tariff = await this.tariffs.findOneBy({ key });
    if (!tariff) throw new NotFoundException({ code: 'TARIFF_NOT_FOUND' });
    await this.tariffs.update(
      { key },
      {
        ...(dto.price !== undefined ? { price: dto.price.toFixed(2) } : {}),
        ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {}),
      },
    );
    return this.tariffs.findOneBy({ key });
  }

  // -------------------------------------------------------- bonus tiers

  listTiers() {
    return this.tiers.find({ order: { minAmount: 'ASC' } });
  }

  async createTier(dto: CreateBonusTierDto) {
    if (await this.tiers.existsBy({ minAmount: dto.minAmount.toFixed(2) })) {
      throw new ConflictException({
        code: 'TIER_EXISTS',
        message: 'A tier with this minimum already exists',
      });
    }
    await this.tiers.insert({
      minAmount: dto.minAmount.toFixed(2),
      percent: dto.percent,
    });
    return this.listTiers();
  }

  async updateTier(id: string, dto: UpdateBonusTierDto) {
    const tier = await this.tiers.findOneBy({ id });
    if (!tier) throw new NotFoundException({ code: 'TIER_NOT_FOUND' });
    if (
      dto.minAmount !== undefined &&
      (await this.tiers.exists({
        where: { minAmount: dto.minAmount.toFixed(2) },
      })) &&
      Number(tier.minAmount) !== dto.minAmount
    ) {
      throw new ConflictException({ code: 'TIER_EXISTS' });
    }
    await this.tiers.update(
      { id },
      {
        ...(dto.minAmount !== undefined ? { minAmount: dto.minAmount.toFixed(2) } : {}),
        ...(dto.percent !== undefined ? { percent: dto.percent } : {}),
        ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {}),
      },
    );
    return this.tiers.findOneBy({ id });
  }

  async removeTier(id: string) {
    const tier = await this.tiers.findOneBy({ id });
    if (!tier) throw new NotFoundException({ code: 'TIER_NOT_FOUND' });
    await this.tiers.delete({ id });
    return { deleted: id };
  }

  // ----------------------------------------------------------- payments

  /** Paged top-ups hydrated with their users — two keyed reads, no joins. */
  async listPayments(query: AdminPaymentsQueryDto) {
    const [rows, total] = await this.payments.findAndCount({
      where: query.status ? { status: query.status } : {},
      order: { createdAt: 'DESC' },
      take: query.limit ?? 20,
      skip: query.offset ?? 0,
    });
    const userById = await this.usersById(rows.map((r) => r.userId));
    return {
      total,
      items: rows.map((p) => ({
        id: p.id,
        amount: p.amount,
        bonusAmount: p.bonusAmount,
        status: p.status,
        clickTransId: p.clickTransId,
        clickError: p.clickError,
        paidAt: p.paidAt,
        createdAt: p.createdAt,
        user: userById.get(p.userId) ?? null,
      })),
    };
  }

  // ------------------------------------------------------------ wallets

  async listWallets(query: PageDto) {
    const [rows, total] = await this.wallets.findAndCount({
      order: { balance: 'DESC' },
      take: query.limit ?? 20,
      skip: query.offset ?? 0,
    });
    const userById = await this.usersById(rows.map((r) => r.userId));
    return {
      total,
      items: rows.map((w) => ({
        userId: w.userId,
        balance: w.balance,
        updatedAt: w.updatedAt,
        user: userById.get(w.userId) ?? null,
      })),
    };
  }

  /** Manual credit/debit from the dashboard — always leaves a ledger row. */
  async adjust(userId: string, dto: AdminAdjustDto) {
    if (!dto.amount) throw new BadRequestException({ code: 'INVALID_AMOUNT' });
    if (!(await this.users.existsBy({ id: userId }))) {
      throw new NotFoundException({ code: 'USER_NOT_FOUND' });
    }
    await this.dataSource.transaction(async (manager) => {
      if (dto.amount > 0) {
        await this.wallet.credit(
          manager,
          userId,
          dto.amount.toFixed(2),
          'ADMIN_ADJUST',
          null,
          dto.note,
        );
      } else {
        // Same guarded debit as a purchase: a correction may not overdraw.
        await this.wallet.debit(
          manager,
          userId,
          Math.abs(dto.amount).toFixed(2),
          'ADMIN_ADJUST',
          null,
          dto.note,
        );
      }
    });
    return { userId, balance: await this.wallet.balanceOf(userId) };
  }

  // ------------------------------------------------------------- stats

  /** The overview card's numbers. */
  async overviewStats() {
    const dayAgo = new Date(Date.now() - DAY_MS);
    const weekAgo = new Date(Date.now() - 7 * DAY_MS);
    const [today] = await this.payments.query(
      `SELECT COUNT(*)::int AS count, COALESCE(SUM(amount), 0) AS sum
         FROM click_payments WHERE status = 'PAID' AND paid_at >= $1`,
      [dayAgo],
    );
    const [week] = await this.payments.query(
      `SELECT COALESCE(SUM(amount), 0) AS sum, COALESCE(SUM(bonus_amount), 0) AS bonus
         FROM click_payments WHERE status = 'PAID' AND paid_at >= $1`,
      [weekAgo],
    );
    return {
      paidToday: today.count,
      sumToday: today.sum,
      sumWeek: week.sum,
      bonusWeek: week.bonus,
    };
  }

  private async usersById(ids: string[]) {
    const unique = [...new Set(ids)];
    const rows = unique.length
      ? await this.users.find({
          where: { id: In(unique) },
          select: { id: true, name: true, surname: true, phoneNumber: true },
        })
      : [];
    return new Map(
      rows.map((u) => [
        u.id,
        { id: u.id, name: u.name, surname: u.surname, phoneNumber: u.phoneNumber },
      ]),
    );
  }
}

import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';

/**
 * One rung of the top-up bonus ladder: "from min_amount and up, +percent".
 * A payment's tier is the ACTIVE row with the largest min_amount at or under
 * the paid amount; upper bounds are implicit in the next rung's min.
 */
@Entity('topup_bonus_tiers')
@Unique('uq_bonus_tier_min', ['minAmount'])
export class BonusTier {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Column({ name: 'min_amount', type: 'numeric', precision: 14, scale: 2 })
  minAmount: string;

  @Column({ type: 'int' }) percent: number;

  @Column({ name: 'is_active', type: 'boolean', default: true }) isActive: boolean;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt: Date;
}

import { Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';

/**
 * The price of one paid action. Keys are code (the charge sites name them),
 * so they are immutable; price and visibility are the admin's to change at
 * runtime. An inactive tariff makes its action FREE — the kill switch for
 * promotions and launches.
 */
@Entity('tariffs')
export class Tariff {
  @PrimaryColumn({ type: 'varchar', length: 40 }) key: string;

  @Column({ name: 'name_uz', type: 'varchar', length: 80 }) nameUz: string;
  @Column({ name: 'name_ru', type: 'varchar', length: 80 }) nameRu: string;

  @Column({ type: 'numeric', precision: 14, scale: 2 }) price: string;

  @Column({ name: 'is_active', type: 'boolean', default: true }) isActive: boolean;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt: Date;
}

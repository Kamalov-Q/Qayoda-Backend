import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';

export type WalletTxKind =
  | 'TOPUP'
  | 'TOPUP_BONUS'
  | 'LISTING_POST'
  | 'STORY_POST'
  | 'LISTING_PROMOTE'
  | 'REFUND'
  | 'ADMIN_ADJUST';

/**
 * Append-only ledger — the source of truth for every soum that moved.
 * Positive amount = credit, negative = debit. Never updated, never deleted.
 */
@Entity('wallet_transactions')
export class WalletTransaction {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Index() @Column({ name: 'user_id', type: 'uuid' }) userId: string;

  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;

  @Column({ type: 'varchar', length: 30 }) kind: WalletTxKind;

  /** The listing / story / click payment this row is about, when there is one. */
  @Column({ name: 'reference_id', type: 'uuid', nullable: true })
  referenceId: string | null;

  /** Balance after this row applied — statements without re-summing. */
  @Column({ name: 'balance_after', type: 'numeric', precision: 14, scale: 2 })
  balanceAfter: string;

  @Column({ type: 'text', nullable: true }) note: string | null;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
}

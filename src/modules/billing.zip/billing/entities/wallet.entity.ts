import { Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from 'typeorm';

/**
 * One prepaid balance per user, in soums. Created lazily on first touch.
 * Bonus money is ordinary balance — one number, spendable on anything; the
 * ledger (WalletTransaction) is what tells paid and bonus apart.
 */
@Entity('wallets')
export class Wallet {
  @PrimaryColumn({ name: 'user_id', type: 'uuid' }) userId: string;

  /** Guarded by CHECK (balance >= 0) in the database as the last line. */
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 })
  balance: string;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt: Date;
}

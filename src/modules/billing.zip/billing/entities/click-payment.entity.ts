import {
  Column,
  CreateDateColumn,
  Entity,
  Generated,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

export type ClickPaymentStatus = 'CREATED' | 'PREPARED' | 'PAID' | 'CANCELLED';

/**
 * One attempt to top the wallet up through Click. The row IS the order: its
 * uuid travels to Click as `transaction_param` and returns in both webhooks
 * as `merchant_trans_id`; `prepareId` (integer — Click's examples treat
 * merchant_prepare_id as numeric) is what Prepare hands back and Complete
 * must echo.
 */
@Entity('click_payments')
export class ClickPayment {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Index({ unique: true })
  @Column({ name: 'prepare_id', type: 'int' })
  @Generated('increment')
  prepareId: number;

  @Index() @Column({ name: 'user_id', type: 'uuid' }) userId: string;

  /** Soums the user pays — the exact figure Click must charge. */
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;

  /** The tier bonus credited on top, fixed at the moment of crediting. */
  @Column({ name: 'bonus_amount', type: 'numeric', precision: 14, scale: 2, default: 0 })
  bonusAmount: string;

  @Index()
  @Column({ type: 'varchar', length: 20, default: 'CREATED' })
  status: ClickPaymentStatus;

  @Column({ name: 'click_trans_id', type: 'bigint', nullable: true })
  clickTransId: string | null;

  @Column({ name: 'click_paydoc_id', type: 'bigint', nullable: true })
  clickPaydocId: string | null;

  /** Click's negative error code when it cancelled, for the audit trail. */
  @Column({ name: 'click_error', type: 'int', nullable: true })
  clickError: number | null;

  @Column({ name: 'paid_at', type: 'timestamptz', nullable: true })
  paidAt: Date | null;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' }) updatedAt: Date;
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from '../auth/auth.module';
import { Wallet } from './entities/wallet.entity';
import { WalletTransaction } from './entities/wallet-transaction.entity';
import { ClickPayment } from './entities/click-payment.entity';
import { Tariff } from './entities/tariff.entity';
import { BonusTier } from './entities/bonus-tier.entity';
import { User } from '../users/entities/user.entity';
import { WalletService } from './wallet.service';
import { ClickService } from './click.service';
import { BillingAdminService } from './billing-admin.service';
import { BillingAdminController } from './billing-admin.controller';
import { ClickWebhookController, WalletController } from './billing.controller';

/**
 * Money: the prepaid wallet, its ledger, Click top-ups with the bonus
 * ladder, and the tariffs the paid actions charge. ListingsModule and
 * StoriesModule import this for WalletService.charge(); nothing here
 * imports them, so there is no cycle.
 */
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Wallet,
      WalletTransaction,
      ClickPayment,
      Tariff,
      BonusTier,
      User,
    ]),
    AuthModule,
  ],
  controllers: [WalletController, ClickWebhookController, BillingAdminController],
  providers: [WalletService, ClickService, BillingAdminService],
  exports: [WalletService, BillingAdminService],
})
export class BillingModule {}

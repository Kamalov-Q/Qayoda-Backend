import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAccessGuard } from '../auth/guards/jwt-access.guard';
import { Roles, RolesGuard } from '../../shared/guards/roles.guard';
import { UserRole } from '../../shared/enums';
import { BillingAdminService } from './billing-admin.service';
import {
  AdminAdjustDto,
  AdminPaymentsQueryDto,
  CreateBonusTierDto,
  PageDto,
  UpdateBonusTierDto,
  UpdateTariffDto,
} from './dto/billing.dto';

@ApiTags('Admin')
@ApiBearerAuth()
@Controller('admin')
@UseGuards(JwtAccessGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class BillingAdminController {
  constructor(private readonly admin: BillingAdminService) {}

  @ApiOperation({ summary: 'The paid actions and their prices' })
  @Get('tariffs')
  tariffs() {
    return this.admin.listTariffs();
  }

  @ApiOperation({
    summary: 'Change a tariff price or visibility',
    description: 'Keys are fixed in code. Inactive = the action becomes free.',
  })
  @Patch('tariffs/:key')
  updateTariff(@Param('key') key: string, @Body() dto: UpdateTariffDto) {
    return this.admin.updateTariff(key, dto);
  }

  @ApiOperation({ summary: 'Top-up bonus ladder, ascending' })
  @Get('bonus-tiers')
  tiers() {
    return this.admin.listTiers();
  }

  @ApiOperation({ summary: 'Add a bonus tier' })
  @Post('bonus-tiers')
  createTier(@Body() dto: CreateBonusTierDto) {
    return this.admin.createTier(dto);
  }

  @ApiOperation({ summary: 'Edit a bonus tier' })
  @Patch('bonus-tiers/:id')
  updateTier(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateBonusTierDto) {
    return this.admin.updateTier(id, dto);
  }

  @ApiOperation({ summary: 'Delete a bonus tier' })
  @Delete('bonus-tiers/:id')
  removeTier(@Param('id', ParseUUIDPipe) id: string) {
    return this.admin.removeTier(id);
  }

  @ApiOperation({ summary: 'Click top-ups, newest first, with users' })
  @Get('payments')
  payments(@Query() query: AdminPaymentsQueryDto) {
    return this.admin.listPayments(query);
  }

  @ApiOperation({ summary: 'Wallet balances, largest first, with users' })
  @Get('wallets')
  wallets(@Query() query: PageDto) {
    return this.admin.listWallets(query);
  }

  @ApiOperation({
    summary: 'Manual balance adjustment',
    description:
      'Positive credits, negative debits; a debit may not push the balance below zero. Always writes an ADMIN_ADJUST ledger row with the note.',
  })
  @Post('wallets/:userId/adjust')
  adjust(
    @Param('userId', ParseUUIDPipe) userId: string,
    @Body() dto: AdminAdjustDto,
  ) {
    return this.admin.adjust(userId, dto);
  }
}

import {
  Body,
  Controller,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiExcludeController,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { SkipThrottle } from '@nestjs/throttler';
import { JwtAccessGuard } from '../auth/guards/jwt-access.guard';
import { PhoneRequiredGuard } from '../auth/guards/phone-required.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import type { AuthUser } from '../auth/types/auth-user.type';
import { WalletService } from './wallet.service';
import { ClickService } from './click.service';
import { PageDto, TopupDto } from './dto/billing.dto';

@ApiTags('Wallet')
@ApiBearerAuth('access-token')
@Controller('wallet')
@UseGuards(JwtAccessGuard)
export class WalletController {
  constructor(
    private readonly wallet: WalletService,
    private readonly click: ClickService,
  ) {}

  @ApiOperation({
    summary: 'Balance, tariffs and bonus tiers',
    description:
      'Everything the wallet screen renders: the balance, the current price of each paid action, and the active top-up bonus ladder (for the "+X%" sheet and the local bonus preview).',
  })
  @Get()
  overview(@CurrentUser() user: AuthUser) {
    return this.wallet.overview(user.sub);
  }

  @ApiOperation({ summary: 'Ledger, newest first' })
  @Get('transactions')
  transactions(@CurrentUser() user: AuthUser, @Query() query: PageDto) {
    return this.wallet.listTransactions(user.sub, query.limit, query.offset);
  }

  @ApiOperation({
    summary: 'Start a Click top-up',
    description:
      'Creates the order and returns the my.click.uz checkout URL to open in the browser. The credit lands via the SHOP API webhooks; poll GET /wallet/topup/:id. `bonusPreview` is what the current tiers would add — informational, the authoritative bonus is fixed when the payment completes.',
  })
  // Money needs an account answerable at a verified number — the same gate
  // as the other consequential actions.
  @UseGuards(PhoneRequiredGuard)
  @Post('topup')
  topup(@CurrentUser() user: AuthUser, @Body() dto: TopupDto) {
    return this.click.createTopup(user.sub, dto.amount);
  }

  @ApiOperation({ summary: 'One top-up, for polling until PAID' })
  @Get('topup/:id')
  topupStatus(
    @CurrentUser() user: AuthUser,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.click.getTopup(user.sub, id);
  }
}

// Click's webhooks: form-urlencoded in, JSON out, HTTP 200 always. No class
// DTO on purpose — the MD5 signature is the authentication, and the global
// forbidNonWhitelisted pipe would bounce the request if Click ever adds a
// field. The throttler is skipped the same way as the Telegram webhook:
// Click retries on failure, and a throttled retry becomes a storm.
@ApiExcludeController()
@SkipThrottle()
@Controller('payments/click')
export class ClickWebhookController {
  constructor(private readonly click: ClickService) {}

  @Post('prepare')
  @HttpCode(200)
  prepare(@Body() body: Record<string, string>) {
    return this.click.prepare(body);
  }

  @Post('complete')
  @HttpCode(200)
  complete(@Body() body: Record<string, string>) {
    return this.click.complete(body);
  }
}

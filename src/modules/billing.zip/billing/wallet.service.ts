import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  OnApplicationBootstrap,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, EntityManager, Repository } from 'typeorm';
import { Wallet } from './entities/wallet.entity';
import { WalletTransaction, WalletTxKind } from './entities/wallet-transaction.entity';
import { Tariff } from './entities/tariff.entity';
import { BonusTier } from './entities/bonus-tier.entity';
import { User } from '../users/entities/user.entity';
import { UserRole } from '../../shared/enums';
import {
  DEFAULT_BONUS_TIERS,
  DEFAULT_TARIFFS,
  TariffKey,
} from './billing.constants';

/** All wallet math in integer tiyin — numeric strings in, no float drift. */
const toTiyin = (soums: string | number) => Math.round(Number(soums) * 100);
const toSoums = (tiyin: number) => (tiyin / 100).toFixed(2);

@Injectable()
export class WalletService implements OnApplicationBootstrap {
  private readonly logger = new Logger(WalletService.name);

  constructor(
    @InjectRepository(Wallet) private readonly wallets: Repository<Wallet>,
    @InjectRepository(WalletTransaction)
    private readonly transactions: Repository<WalletTransaction>,
    @InjectRepository(Tariff) private readonly tariffs: Repository<Tariff>,
    @InjectRepository(BonusTier) private readonly tiers: Repository<BonusTier>,
    private readonly dataSource: DataSource,
  ) {}

  /** First boot only, same pattern as categories/amenities: seed when EMPTY. */
  async onApplicationBootstrap(): Promise<void> {
    try {
      if ((await this.tariffs.count()) === 0) {
        await this.tariffs.insert(
          DEFAULT_TARIFFS.map((t) => ({ ...t, price: t.price.toFixed(2) })),
        );
        this.logger.log(`Seeded ${DEFAULT_TARIFFS.length} tariffs.`);
      }
      if ((await this.tiers.count()) === 0) {
        await this.tiers.insert(
          DEFAULT_BONUS_TIERS.map((t) => ({
            minAmount: t.minAmount.toFixed(2),
            percent: t.percent,
          })),
        );
        this.logger.log(`Seeded ${DEFAULT_BONUS_TIERS.length} bonus tiers.`);
      }
    } catch (e) {
      // Never block startup over seed data.
      this.logger.error(`Billing seed failed: ${e instanceof Error ? e.message : e}`);
    }
  }

  // ------------------------------------------------------------- reads

  async balanceOf(userId: string): Promise<string> {
    const w = await this.wallets.findOneBy({ userId });
    return w?.balance ?? '0.00';
  }

  /** Everything the app's wallet screen renders in one request. */
  async overview(userId: string) {
    const [balance, tariffs, tiers] = await Promise.all([
      this.balanceOf(userId),
      this.tariffs.find({ order: { key: 'ASC' } }),
      this.activeTiers(),
    ]);
    return {
      balance,
      tariffs: tariffs.map(({ key, nameUz, nameRu, price, isActive }) => ({
        key,
        nameUz,
        nameRu,
        price,
        isActive,
      })),
      bonusTiers: tiers.map(({ minAmount, percent }) => ({ minAmount, percent })),
    };
  }

  async listTransactions(userId: string, limit = 20, offset = 0) {
    const [items, total] = await this.transactions.findAndCount({
      where: { userId },
      order: { createdAt: 'DESC' },
      take: Math.min(limit, 50),
      skip: offset,
    });
    return { total, items };
  }

  activeTiers() {
    return this.tiers.find({
      where: { isActive: true },
      order: { minAmount: 'ASC' },
    });
  }

  /**
   * The bonus the CURRENT ladder gives for `amount` soums, in soums.
   * Integer-tiyin math, rounded down — the house never owes fractions.
   */
  async bonusFor(amount: string | number): Promise<string> {
    const tiers = await this.activeTiers();
    const paid = toTiyin(amount);
    let percent = 0;
    for (const t of tiers) {
      if (paid >= toTiyin(t.minAmount)) percent = t.percent;
    }
    return toSoums(Math.floor((paid * percent) / 100));
  }

  // ------------------------------------------------------------ writes

  /**
   * Debit one paid action from the wallet, INSIDE the caller's transaction:
   * pass the EntityManager of the transaction that also performs the
   * purchased effect, so a failure after the charge rolls the money back
   * automatically. Returns the charged amount in soums ("0.00" when free).
   *
   * Free when: the tariff is missing/inactive/zero, or the user is an ADMIN.
   */
  async charge(
    manager: EntityManager,
    userId: string,
    key: TariffKey,
    referenceId?: string,
  ): Promise<string> {
    const user = await manager.getRepository(User).findOne({
      where: { id: userId },
      select: { id: true, role: true },
    });
    if (user?.role === UserRole.ADMIN) return '0.00';

    const tariff = await manager.getRepository(Tariff).findOneBy({ key });
    if (!tariff || !tariff.isActive || toTiyin(tariff.price) <= 0) return '0.00';

    await this.debit(manager, userId, tariff.price, key, referenceId ?? null, null);
    return tariff.price;
  }

  /**
   * The one place balance goes DOWN. Conditional UPDATE — not read-then-write
   * — so two concurrent spends can never drive the balance negative; the
   * CHECK constraint in the database is the backstop behind even this.
   */
  async debit(
    manager: EntityManager,
    userId: string,
    amount: string,
    kind: WalletTxKind,
    referenceId: string | null,
    note: string | null,
  ): Promise<void> {
    await this.ensureWallet(manager, userId);

    const result = await manager
      .createQueryBuilder()
      .update(Wallet)
      .set({ balance: () => 'balance - :amount' })
      .where('user_id = :userId AND balance >= :amount')
      .setParameters({ userId, amount })
      .execute();

    if (!result.affected) {
      const balance = await manager
        .getRepository(Wallet)
        .findOneBy({ userId })
        .then((w) => w?.balance ?? '0.00');
      // 402, so the app knows to open the top-up sheet with the shortfall.
      throw new HttpException(
        {
          code: 'INSUFFICIENT_FUNDS',
          message: 'Not enough balance',
          required: amount,
          balance,
        },
        HttpStatus.PAYMENT_REQUIRED,
      );
    }

    await this.writeLedger(manager, userId, `-${amount}`, kind, referenceId, note);
  }

  /** The one place balance goes UP. */
  async credit(
    manager: EntityManager,
    userId: string,
    amount: string,
    kind: WalletTxKind,
    referenceId: string | null,
    note: string | null,
  ): Promise<void> {
    if (toTiyin(amount) <= 0) {
      throw new BadRequestException({ code: 'INVALID_AMOUNT' });
    }
    await this.ensureWallet(manager, userId);
    await manager
      .createQueryBuilder()
      .update(Wallet)
      .set({ balance: () => 'balance + :amount' })
      .where('user_id = :userId')
      .setParameters({ userId, amount })
      .execute();
    await this.writeLedger(manager, userId, amount, kind, referenceId, note);
  }

  /** Lazy wallet row; ON CONFLICT keeps concurrent first-touches harmless. */
  private async ensureWallet(manager: EntityManager, userId: string) {
    await manager.query(
      `INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING`,
      [userId],
    );
  }

  private async writeLedger(
    manager: EntityManager,
    userId: string,
    amount: string,
    kind: WalletTxKind,
    referenceId: string | null,
    note: string | null,
  ) {
    // Read back inside the same transaction: balance_after is exact.
    const wallet = await manager.getRepository(Wallet).findOneBy({ userId });
    await manager.getRepository(WalletTransaction).insert({
      userId,
      amount: Number(amount).toFixed(2),
      kind,
      referenceId,
      balanceAfter: wallet?.balance ?? '0.00',
      note,
    });
  }
}

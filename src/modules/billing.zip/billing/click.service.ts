import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { createHash } from 'crypto';
import { ClickPayment } from './entities/click-payment.entity';
import { WalletService } from './wallet.service';
import {
  CLICK_ACTION_COMPLETE,
  CLICK_ACTION_NOT_FOUND,
  CLICK_ACTION_PREPARE,
  CLICK_ALREADY_PAID,
  CLICK_INVALID_AMOUNT,
  CLICK_OK,
  CLICK_SIGN_CHECK_FAILED,
  CLICK_TRANSACTION_CANCELLED,
  CLICK_TRANSACTION_NOT_FOUND,
  CLICK_USER_NOT_FOUND,
} from './billing.constants';

/** The JSON shape both webhook handlers answer — Click's required format. */
export interface ClickReply {
  click_trans_id?: string;
  merchant_trans_id?: string;
  merchant_prepare_id?: number;
  merchant_confirm_id?: number;
  error: number;
  error_note: string;
}

/**
 * Click SHOP API (docs.click.uz): Click POSTs Prepare (action=0) and
 * Complete (action=1) to us as form-urlencoded; we answer JSON with HTTP 200
 * always — outcomes live in the `error` field. The MD5 signature is the
 * authentication.
 */
@Injectable()
export class ClickService {
  private readonly logger = new Logger(ClickService.name);

  constructor(
    @InjectRepository(ClickPayment)
    private readonly payments: Repository<ClickPayment>,
    private readonly wallet: WalletService,
    private readonly config: ConfigService,
    private readonly dataSource: DataSource,
  ) {}

  /**
   * Step 0 — the app asks to top up. Creates the order and builds the
   * checkout URL (docs.click.uz/en/click-button): the order's uuid rides as
   * `transaction_param` and returns as `merchant_trans_id` in the webhooks.
   */
  async createTopup(userId: string, amount: number) {
    const payment = await this.payments.save(
      this.payments.create({
        userId,
        amount: amount.toFixed(2),
        status: 'CREATED',
      }),
    );

    const params = new URLSearchParams({
      service_id: this.config.getOrThrow<string>('CLICK_SERVICE_ID'),
      merchant_id: this.config.getOrThrow<string>('CLICK_MERCHANT_ID'),
      amount: amount.toFixed(2),
      transaction_param: payment.id,
      return_url: this.config.get<string>('CLICK_RETURN_URL') ?? '',
    });

    return {
      paymentId: payment.id,
      payUrl: `https://my.click.uz/services/pay?${params.toString()}`,
      // Informational: what the CURRENT ladder would add. The authoritative
      // bonus is computed at Complete, against the tiers live at that moment.
      bonusPreview: await this.wallet.bonusFor(amount),
    };
  }

  /** The app polls this to flip its UI once the webhooks have done the work. */
  async getTopup(userId: string, id: string) {
    const p = await this.payments.findOneBy({ id, userId });
    if (!p) throw new NotFoundException('Payment not found');
    return {
      id: p.id,
      status: p.status,
      amount: p.amount,
      bonusAmount: p.bonusAmount,
      paidAt: p.paidAt,
    };
  }

  // ------------------------------------------------- SHOP API webhooks

  /**
   * Prepare (action=0): "does this order exist and is the amount right?"
   * Answering 0 reserves it; merchant_prepare_id must be echoed in Complete.
   * A Prepare retry on a PREPARED row is fine — same answer again.
   */
  async prepare(body: Record<string, string>): Promise<ClickReply> {
    const base = {
      click_trans_id: body.click_trans_id,
      merchant_trans_id: body.merchant_trans_id,
    };

    if (body.action !== CLICK_ACTION_PREPARE) {
      return { ...base, error: CLICK_ACTION_NOT_FOUND, error_note: 'Action not found' };
    }
    if (!this.signatureValid(body, false)) {
      return { ...base, error: CLICK_SIGN_CHECK_FAILED, error_note: 'SIGN CHECK FAILED!' };
    }

    const payment = await this.findByMerchantTransId(body.merchant_trans_id);
    if (!payment) {
      return { ...base, error: CLICK_USER_NOT_FOUND, error_note: 'Order not found' };
    }
    if (payment.status === 'PAID') {
      return { ...base, error: CLICK_ALREADY_PAID, error_note: 'Already paid' };
    }
    if (payment.status === 'CANCELLED') {
      return { ...base, error: CLICK_TRANSACTION_CANCELLED, error_note: 'Transaction cancelled' };
    }
    if (!this.amountMatches(payment, body.amount)) {
      return { ...base, error: CLICK_INVALID_AMOUNT, error_note: 'Incorrect parameter amount' };
    }

    payment.status = 'PREPARED';
    payment.clickTransId = body.click_trans_id ?? null;
    payment.clickPaydocId = body.click_paydoc_id ?? null;
    await this.payments.save(payment);

    return {
      ...base,
      merchant_prepare_id: payment.prepareId,
      error: CLICK_OK,
      error_note: 'Success',
    };
  }

  /**
   * Complete (action=1): the money moved — or Click failed the charge, which
   * it reports as a negative `error` in the REQUEST and the docs require us
   * to cancel in our billing. On success: flip to PAID and credit the wallet
   * (amount + tier bonus) in ONE transaction; the conditional status UPDATE
   * is the lock that makes retries credit exactly once.
   */
  async complete(body: Record<string, string>): Promise<ClickReply> {
    const base = {
      click_trans_id: body.click_trans_id,
      merchant_trans_id: body.merchant_trans_id,
    };

    if (body.action !== CLICK_ACTION_COMPLETE) {
      return { ...base, error: CLICK_ACTION_NOT_FOUND, error_note: 'Action not found' };
    }
    if (!this.signatureValid(body, true)) {
      return { ...base, error: CLICK_SIGN_CHECK_FAILED, error_note: 'SIGN CHECK FAILED!' };
    }

    const payment = await this.findByMerchantTransId(body.merchant_trans_id);
    if (!payment) {
      return { ...base, error: CLICK_USER_NOT_FOUND, error_note: 'Order not found' };
    }
    if (String(payment.prepareId) !== body.merchant_prepare_id) {
      return { ...base, error: CLICK_TRANSACTION_NOT_FOUND, error_note: 'Transaction does not exist' };
    }
    if (payment.status === 'PAID') {
      return { ...base, error: CLICK_ALREADY_PAID, error_note: 'Already paid' };
    }
    if (payment.status === 'CANCELLED') {
      return { ...base, error: CLICK_TRANSACTION_CANCELLED, error_note: 'Transaction cancelled' };
    }
    if (!this.amountMatches(payment, body.amount)) {
      return { ...base, error: CLICK_INVALID_AMOUNT, error_note: 'Incorrect parameter amount' };
    }

    // Click's side failed the charge: cancel in our billing, as the docs
    // require for a negative incoming code.
    const clickError = Number(body.error ?? '0');
    if (clickError < 0) {
      await this.payments.update(
        { id: payment.id },
        { status: 'CANCELLED', clickError },
      );
      return { ...base, error: CLICK_TRANSACTION_CANCELLED, error_note: 'Transaction cancelled' };
    }

    const bonus = await this.wallet.bonusFor(payment.amount);

    const credited = await this.dataSource.transaction(async (manager) => {
      // The lock: only the request that flips PREPARED→PAID gets to credit.
      const claim = await manager.update(
        ClickPayment,
        { id: payment.id, status: 'PREPARED' },
        { status: 'PAID', bonusAmount: bonus, paidAt: new Date() },
      );
      if (!claim.affected) return false;

      // Two ledger rows, so a statement reads "200 000 + 20 000 bonus"
      // rather than an unexplained 220 000.
      await this.wallet.credit(manager, payment.userId, payment.amount, 'TOPUP', payment.id, null);
      if (Number(bonus) > 0) {
        await this.wallet.credit(
          manager,
          payment.userId,
          bonus,
          'TOPUP_BONUS',
          payment.id,
          null,
        );
      }
      return true;
    });

    if (!credited) {
      return { ...base, error: CLICK_ALREADY_PAID, error_note: 'Already paid' };
    }

    this.logger.log(
      `Click top-up ${payment.id} paid: ${payment.amount} + ${bonus} bonus`,
    );

    return {
      ...base,
      merchant_confirm_id: payment.prepareId,
      error: CLICK_OK,
      error_note: 'Success',
    };
  }

  // ------------------------------------------------------------ helpers

  /** merchant_trans_id arrives as text; a non-uuid must be "not found", not a 500. */
  private findByMerchantTransId(id: string | undefined) {
    if (!id || !/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(id)) return null;
    return this.payments.findOneBy({ id });
  }

  /** Click sends soums as "N.NN"; numeric compare with one tiyin of slack. */
  private amountMatches(payment: ClickPayment, amount: string | undefined) {
    return Math.abs(Number(payment.amount) - Number(amount)) < 0.01;
  }

  /**
   * docs.click.uz/en/shop-api/requests:
   *   Prepare : md5(click_trans_id + service_id + SECRET_KEY +
   *                 merchant_trans_id + amount + action + sign_time)
   *   Complete: the same with merchant_prepare_id inserted BETWEEN
   *                 merchant_trans_id and amount.
   * Every part is the literal string Click sent, sign_time included.
   */
  private signatureValid(body: Record<string, string>, withPrepareId: boolean): boolean {
    const secret = this.config.get<string>('CLICK_SECRET_KEY');
    if (!secret) return false;
    const parts = [
      body.click_trans_id,
      body.service_id,
      secret,
      body.merchant_trans_id,
      ...(withPrepareId ? [body.merchant_prepare_id] : []),
      body.amount,
      body.action,
      body.sign_time,
    ];
    if (parts.some((p) => p === undefined)) return false;
    const digest = createHash('md5').update(parts.join('')).digest('hex');
    return digest === (body.sign_string ?? '').toLowerCase();
  }
}

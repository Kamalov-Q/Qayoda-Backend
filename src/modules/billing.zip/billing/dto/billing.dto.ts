import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
} from 'class-validator';
import { TOPUP_MAX, TOPUP_MIN } from '../billing.constants';

const trim = ({ value }: { value: unknown }) =>
  typeof value === 'string' ? value.trim() : value;

export class TopupDto {
  @ApiProperty({ example: 200000, minimum: TOPUP_MIN, maximum: TOPUP_MAX, description: 'Soums.' })
  @Type(() => Number)
  @IsNumber()
  @Min(TOPUP_MIN)
  @Max(TOPUP_MAX)
  amount: number;
}

export class PageDto {
  @ApiPropertyOptional({ minimum: 1, maximum: 50, default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  limit?: number;

  @ApiPropertyOptional({ minimum: 0, default: 0 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  offset?: number;
}

export class AdminPaymentsQueryDto extends PageDto {
  @ApiPropertyOptional({ enum: ['CREATED', 'PREPARED', 'PAID', 'CANCELLED'] })
  @IsOptional()
  @IsIn(['CREATED', 'PREPARED', 'PAID', 'CANCELLED'])
  status?: 'CREATED' | 'PREPARED' | 'PAID' | 'CANCELLED';
}

export class UpdateTariffDto {
  @ApiPropertyOptional({ example: 5000, minimum: 0, maximum: 100_000_000 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(100_000_000)
  price?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class CreateBonusTierDto {
  @ApiProperty({ example: 100000, minimum: 1000 })
  @Type(() => Number)
  @IsNumber()
  @Min(1000)
  @Max(1_000_000_000)
  minAmount: number;

  @ApiProperty({ example: 10, minimum: 0, maximum: 100 })
  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(100)
  percent: number;
}

export class UpdateBonusTierDto {
  @ApiPropertyOptional({ minimum: 1000 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1000)
  @Max(1_000_000_000)
  minAmount?: number;

  @ApiPropertyOptional({ minimum: 0, maximum: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(100)
  percent?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class AdminAdjustDto {
  @ApiProperty({
    example: -5000,
    description: 'Soums; positive credits, negative debits. Never below zero balance.',
  })
  @Type(() => Number)
  @IsNumber()
  @Min(-100_000_000)
  @Max(100_000_000)
  amount: number;

  @ApiProperty({ maxLength: 200, example: 'Compensation for a failed promotion' })
  @Transform(trim)
  @IsString()
  @MaxLength(200)
  note: string;
}

/** The paid actions. Charge sites reference these keys; they never change. */
export const TARIFF_KEYS = ['LISTING_POST', 'STORY_POST', 'LISTING_PROMOTE'] as const;
export type TariffKey = (typeof TARIFF_KEYS)[number];

/** How long one promotion payment keeps a listing on top. */
export const PROMOTE_DAYS = 7;

/** Seed data, not logic — first boot on an empty table only. */
export const DEFAULT_TARIFFS: {
  key: TariffKey;
  nameUz: string;
  nameRu: string;
  price: number;
}[] = [
  { key: 'LISTING_POST', nameUz: "E'lon joylash", nameRu: 'Размещение объявления', price: 5000 },
  { key: 'STORY_POST', nameUz: 'Hikoya joylash', nameRu: 'Публикация истории', price: 5000 },
  {
    key: 'LISTING_PROMOTE',
    nameUz: `E'lonni TOPga chiqarish (${PROMOTE_DAYS} kun)`,
    nameRu: `Поднять в ТОП (${PROMOTE_DAYS} дней)`,
    price: 10000,
  },
];

/** The Joymee-style bonus ladder the product launches with. */
export const DEFAULT_BONUS_TIERS: { minAmount: number; percent: number }[] = [
  { minAmount: 100_000, percent: 10 },
  { minAmount: 500_000, percent: 15 },
  { minAmount: 1_000_000, percent: 20 },
  { minAmount: 2_000_000, percent: 25 },
  { minAmount: 3_000_000, percent: 30 },
  { minAmount: 5_000_000, percent: 40 },
];

export const TOPUP_MIN = 1_000;
export const TOPUP_MAX = 10_000_000;

/**
 * Merchant-side status codes from docs.click.uz (SHOP API — Errors). Click
 * retries on transport failures but trusts these as final.
 */
export const CLICK_OK = 0;
export const CLICK_SIGN_CHECK_FAILED = -1;
export const CLICK_INVALID_AMOUNT = -2;
export const CLICK_ACTION_NOT_FOUND = -3;
export const CLICK_ALREADY_PAID = -4;
export const CLICK_USER_NOT_FOUND = -5;
export const CLICK_TRANSACTION_NOT_FOUND = -6;
export const CLICK_TRANSACTION_CANCELLED = -9;

export const CLICK_ACTION_PREPARE = '0';
export const CLICK_ACTION_COMPLETE = '1';
